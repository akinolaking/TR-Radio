angular.module('your_app_name.config', [])
.constant('WORDPRESS_API_URL', 'http://www.triumphantradio.com/gsapi
')
.constant('WORDPRESS_PUSH_URL', 'https://triumphantradio.onesignal.com')
.constant('GCM_SENDER_ID', '574597432927')

;
