# DOCUMENTATION:
Please read the documentation here: http://bit.ly/ionicthemes-ionwordpress
